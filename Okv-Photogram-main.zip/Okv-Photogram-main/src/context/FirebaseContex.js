import { createContext } from "react";

const firebaseContex = createContext();

export default firebaseContex;